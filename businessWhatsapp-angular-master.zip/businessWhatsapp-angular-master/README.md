# Business Whatsapp - Angular

The software is based on `https://github.com/rlassche/ng6_websockets` and
`https://github.com/rlassche/mojolicious_websockets`.

